Disciplina: ELF52
Atividade Prática: 1

Equipe: 
João Vitor Santos Anacleto, 1802836
Nilton Miguel Guimarães de Souza, 2237164
Patrick Grochewski, 2307529

Data: 09/08/2024

o diretório etapas contém antigas iterações do main.s a ordem dos arquivos é:

1) divisivel
2) primo
3) desordenada
4) ordenada

depurado.png é uma captura do fim da execução bem sucedida do código.
