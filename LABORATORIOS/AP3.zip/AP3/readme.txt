Disciplina: ELF52
Atividade Prática: 3
Equipe: 
João Vitor Santos Anacleto, 1802836
Nilton Miguel Guimarães de Souza, 2237164
Patrick Grochewski, 2307529
Data: 20/08/2024
