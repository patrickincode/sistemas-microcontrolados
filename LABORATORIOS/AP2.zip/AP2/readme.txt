Disciplina: ELF52
Atividade Prática: 2

Equipe: 
João Vitor Santos Anacleto, 1802836
Nilton Miguel Guimarães de Souza, 2237164
Patrick Grochewski, 2307529

Data: 0x10/0x08/2024

o diretório iterações contém antigas versões do main.s a ordem dos arquivos é:

1) rascunho.s
2) contador.s
3) loops_separados.s
4) botao_rascunho.s
5) botao_melhor.s
6) velocidade_correta.s
7) main.s
